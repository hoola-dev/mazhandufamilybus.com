    <div class="content-body">
      <div class="container page">
        <h2 class="title-section mb-5"><span>Disclaimer</span> </h2>
        
        
      </div>
        
        <!-- call out section-->
      <section class="page-section cws_prlx_section bg-white-80 pb-60 pt-60"><img src="<?php echo $tpl['base_url']; ?>app/web/pic/parallax-5.jpg" alt class="cws_prlx_layer">
        <div class="container">
          <div class="call-out-box">
            <div class="call-out-wrap alt">
              <h2 class="title-section alt-2 gray">Book your tickets online</h2><a href="#" class="cws-button border-left large alt mb-20">Book Ticket</a>
            </div>
          </div>
        </div>
      </section>
      <!-- ! call out section-->
      <!-- call out section-->
       <section class="page-section pt-30 pb-20 bg-main relative">
        <div class="container">
          <div class="call-out-box clearfix with-icon">
            <div class="row call-out-wrap">
              <div class="col-md-5">
                <h6 class="title-section-top gray font-4">Customer Care</h6>
                <h2 class="title-section alt-2">+260<span> 212 217 118</span></h2>
              </div>
              
            </div>
          </div>
        </div>
      </section>
      <!-- ! call out section-->
    </div>