<!--agents-->
<section id="agents" style="padding-top:0px;min-height:800px;">
    <div class="container">
        <div class="title">
        <!-- <h2 class="flex fadeInUp animated animated" style="visibility: visible; animation-name: fadeInUp;">Mazhandu Family Bus Services</h2>
            <h2 class="flex fadeInUp animated animated" style="visibility: visible; animation-name: fadeInUp;">Our Agents</h2> -->
            <p class="description flex fadeInUp animated animated" style="visibility: visible; animation-name: fadeInUp;">
                <span class="price" style="margin-left: 0px; margin-top: 0px; padding-top: 0px;font-size:18px;">
                    <b>Terms & Conditions</b>
                </span>
            </p>
            <p class="description flex fadeInUp animated animated" style="visibility: visible; animation-name: fadeInUp;width:250px;">
                <span style="margin-left: 0px; margin-top: 0px; padding-top: 0px;font-size:18px;">                        
              
                </span>
            </p>        
        </div>
        <!--end title-->
        <div id="list_agents" style="clear:both;">
             
        </div>
    </div>
</section>
<!--agents-->